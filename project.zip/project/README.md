# Uttarakhand-MATDAAN-E-Voting-2022

A Interactive Way To Solve Conventional Voting.

E-Voting System" is an online voting system. In this system people
who are citizens and whose age is above 18 years of age, and any gender can give his\her
vote online without going to any physical pooling station.


# Snapshots of Voting System

<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-007.jpg?raw=true "/>
<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-008.jpg?raw=true "/>
<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-009.jpg?raw=true "/>
<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-010.jpg?raw=true "/>
<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-011.jpg?raw=true "/>
<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-012.jpg?raw=true "/>
<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-013.jpg?raw=true "/>
<img align="left" src="https://github.com/GariBisht/Uttarakhand-MATDAAN-E-Voting-2022/blob/main/readme%20images/image-014.jpg?raw=true "/>


